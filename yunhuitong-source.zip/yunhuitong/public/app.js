// ===== 全局状态 =====
let ws = null;
let myUserId = null;
let myRoomId = null;
let myName = '';
let isInRoom = false;

// 本地媒体流
let localAudioStream = null;
let localScreenStream = null;
let isMicOn = false;
let isAudioOn = true;
let isSharing = false;

// 远端 peer 连接: userId -> { pc, audioStream, screenStream }
const peers = new Map();

// 成员列表
const members = new Map(); // userId -> { name, isSharing, muted }

// 当前显示的屏幕共享来源
let currentScreenSharerId = null;

// ICE 服务器配置（使用免费的公共 STUN）
const iceConfig = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
  ]
};

// ===== DOM 元素 =====
const $ = (id) => document.getElementById(id);

const serverStatusDot = $('serverStatus');
const serverStatusText = $('serverStatusText');
const meetingEntry = $('meetingEntry');
const meetingRoom = $('meetingRoom');
const roomIdInput = $('roomId');
const nicknameInput = $('nickname');
const createBtn = $('createBtn');
const joinBtn = $('joinBtn');
const leaveBtn = $('leaveBtn');
const currentRoomIdEl = $('currentRoomId');
const memberCountEl = $('memberCount');
const membersListEl = $('membersList');
const screenVideo = $('screenVideo');
const screenPlaceholder = $('screenPlaceholder');
const screenStatusText = $('screenStatusText');
const fullscreenBtn = $('fullscreenBtn');
const micBtn = $('micBtn');
const audioBtn = $('audioBtn');
const shareBtn = $('shareBtn');
const chatMessages = $('chatMessages');
const chatInput = $('chatInput');
const sendBtn = $('sendBtn');

// ===== 初始化 =====
function init() {
  connectWebSocket();
  bindEvents();
  // 自动填充随机昵称
  nicknameInput.value = '用户' + Math.floor(Math.random() * 10000);
  // 自动生成一个随机会议号
  roomIdInput.value = Math.floor(100000 + Math.random() * 900000).toString();
}

// ===== WebSocket 连接 =====
function connectWebSocket() {
  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${location.host}`;

  ws = new WebSocket(wsUrl);

  ws.onopen = () => {
    serverStatusDot.className = 'status-dot online';
    serverStatusText.textContent = '服务端：在线';
  };

  ws.onclose = () => {
    serverStatusDot.className = 'status-dot offline';
    serverStatusText.textContent = '服务端：离线';
    // 自动重连
    setTimeout(connectWebSocket, 3000);
  };

  ws.onerror = () => {
    serverStatusDot.className = 'status-dot offline';
    serverStatusText.textContent = '连接失败';
  };

  ws.onmessage = (event) => {
    let data;
    try {
      data = JSON.parse(event.data);
    } catch (e) {
      return;
    }
    handleMessage(data);
  };
}

function sendWs(data) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data));
  }
}

// ===== 消息处理 =====
function handleMessage(data) {
  switch (data.type) {
    case 'joined':
      handleJoined(data);
      break;
    case 'member-join':
      handleMemberJoin(data.member);
      break;
    case 'member-leave':
      handleMemberLeave(data.userId);
      break;
    case 'offer':
      handleOffer(data.from, data.offer);
      break;
    case 'answer':
      handleAnswer(data.from, data.answer);
      break;
    case 'ice-candidate':
      handleIceCandidate(data.from, data.candidate);
      break;
    case 'chat':
      handleChatMessage(data);
      break;
    case 'chat-history':
      handleChatHistory(data.messages);
      break;
    case 'screen-started':
      handleScreenStarted(data.userId, data.userName);
      break;
    case 'screen-stopped':
      handleScreenStopped(data.userId);
      break;
    case 'screen-offer':
      handleScreenOffer(data.from, data.offer);
      break;
    case 'screen-answer':
      handleScreenAnswer(data.from, data.answer);
      break;
    case 'screen-ice-candidate':
      handleScreenIceCandidate(data.from, data.candidate);
      break;
    case 'mute-update':
      handleMuteUpdate(data.userId, data.muted);
      break;
  }
}

// ===== 加入/离开房间 =====
function joinRoom() {
  const roomId = roomIdInput.value.trim();
  const name = nicknameInput.value.trim();

  if (!roomId) {
    alert('请输入会议号');
    return;
  }
  if (!name) {
    alert('请输入昵称');
    return;
  }

  myName = name;
  myRoomId = roomId;

  sendWs({
    type: 'join',
    roomId,
    name
  });
}

function handleJoined(data) {
  myUserId = data.userId;
  isInRoom = true;

  // 更新 UI
  meetingEntry.classList.add('hidden');
  meetingRoom.classList.remove('hidden');
  currentRoomIdEl.textContent = data.roomId;

  // 初始化成员列表
  members.clear();
  data.members.forEach(m => {
    members.set(m.id, { name: m.name, isSharing: m.isSharing, muted: false });
  });
  updateMemberList();

  // 启用聊天
  chatInput.disabled = false;
  sendBtn.disabled = false;
  micBtn.disabled = false;
  audioBtn.disabled = false;
  shareBtn.disabled = false;

  console.log('已加入房间，我的 ID:', myUserId);
}

function leaveRoom() {
  if (!isInRoom) return;

  // 停止所有媒体
  stopLocalAudio();
  stopScreenShare();

  // 关闭所有 peer 连接
  peers.forEach((peer, uid) => {
    if (peer.pc) peer.pc.close();
    if (peer.screenPc) peer.screenPc.close();
  });
  peers.clear();

  // 发送离开消息
  sendWs({ type: 'leave' });

  // 重置状态
  isInRoom = false;
  myUserId = null;
  myRoomId = null;
  members.clear();
  currentScreenSharerId = null;

  // 更新 UI
  meetingEntry.classList.remove('hidden');
  meetingRoom.classList.add('hidden');
  screenVideo.classList.remove('active');
  screenPlaceholder.style.display = 'block';
  screenStatusText.textContent = '等待屏幕共享';
  fullscreenBtn.disabled = true;

  chatInput.disabled = true;
  sendBtn.disabled = true;
  micBtn.disabled = true;
  audioBtn.disabled = true;
  shareBtn.disabled = true;
  micBtn.classList.remove('active');
  audioBtn.classList.remove('active');
  shareBtn.classList.remove('active');
  micBtn.querySelector('.control-text').textContent = '开麦';
  audioBtn.querySelector('.control-text').textContent = '开启声音';
  shareBtn.querySelector('.control-text').textContent = '共享屏幕';

  chatMessages.innerHTML = '<div class="empty-chat">还没有聊天消息。</div>';
}

// ===== 成员管理 =====
function handleMemberJoin(member) {
  members.set(member.id, { name: member.name, isSharing: member.isSharing, muted: false });
  updateMemberList();

  // 新成员加入时，我们作为已在房间的人，主动发起连接
  // （新成员 ID 比我们后加入，由我们发起 offer）
  if (member.id !== myUserId) {
    createPeerConnection(member.id, true); // true = 我们是发起方
  }
}

function handleMemberLeave(userId) {
  members.delete(userId);
  updateMemberList();

  // 关闭对应的 peer 连接
  const peer = peers.get(userId);
  if (peer) {
    if (peer.pc) peer.pc.close();
    if (peer.screenPc) peer.screenPc.close();
    peers.delete(userId);
  }

  // 如果离开的是屏幕共享者，清除显示
  if (currentScreenSharerId === userId) {
    currentScreenSharerId = null;
    screenVideo.classList.remove('active');
    screenPlaceholder.style.display = 'flex';
    screenStatusText.textContent = '等待屏幕共享';
    fullscreenBtn.disabled = true;
  }
}

function updateMemberList() {
  memberCountEl.textContent = members.size;

  if (members.size === 0) {
    membersListEl.innerHTML = '<div class="empty-members">暂无成员</div>';
    return;
  }

  let html = '';
  members.forEach((info, uid) => {
    const isSelf = uid === myUserId;
    const firstChar = info.name.charAt(0).toUpperCase();
    let statusText = isSelf ? '（我）' : '';
    let statusClass = '';
    if (info.isSharing) {
      statusText = '共享中';
      statusClass = 'sharing';
    } else if (info.muted) {
      statusText = '静音';
      statusClass = 'muted';
    }

    html += `
      <div class="member-item">
        <div class="member-avatar">${firstChar}</div>
        <div class="member-name">${info.name}${isSelf ? '（我）' : ''}</div>
        <div class="member-status ${statusClass}">${statusText}</div>
      </div>
    `;
  });
  membersListEl.innerHTML = html;
}

// ===== WebRTC 语音连接 =====
function createPeerConnection(remoteUserId, isInitiator) {
  if (peers.has(remoteUserId)) {
    const existing = peers.get(remoteUserId);
    if (existing.pc && existing.pc.connectionState !== 'closed') {
      return existing.pc;
    }
  }

  console.log(`创建语音 PeerConnection，对方: ${remoteUserId}, 发起方: ${isInitiator}`);

  const pc = new RTCPeerConnection(iceConfig);

  const peerData = {
    pc,
    screenPc: null,
    audioStream: null,
    screenStream: null
  };
  peers.set(remoteUserId, peerData);

  // 如果我们有本地音频流，添加到连接中
  if (localAudioStream) {
    localAudioStream.getAudioTracks().forEach(track => {
      pc.addTrack(track, localAudioStream);
    });
  }

  // 接收远端音轨
  pc.ontrack = (event) => {
    if (event.track.kind === 'audio') {
      peerData.audioStream = event.streams[0];
      // 创建一个隐藏的 audio 元素播放
      playRemoteAudio(remoteUserId, event.streams[0]);
    }
  };

  // ICE 候选
  pc.onicecandidate = (event) => {
    if (event.candidate) {
      sendWs({
        type: 'ice-candidate',
        to: remoteUserId,
        candidate: event.candidate
      });
    }
  };

  pc.onconnectionstatechange = () => {
    console.log(`语音连接状态 (${remoteUserId}): ${pc.connectionState}`);
    if (pc.connectionState === 'failed' || pc.connectionState === 'closed') {
      // 连接失败，可以在这里做重连逻辑
    }
  };

  // 如果我们是发起方，创建 offer
  if (isInitiator) {
    // 等一下再创建 offer，确保 track 都加上了
    setTimeout(() => {
      pc.createOffer()
        .then(offer => pc.setLocalDescription(offer))
        .then(() => {
          sendWs({
            type: 'offer',
            to: remoteUserId,
            offer: pc.localDescription
          });
        })
        .catch(err => console.error('创建 offer 失败:', err));
    }, 500);
  }

  return pc;
}

function handleOffer(from, offer) {
  console.log(`收到 offer 来自 ${from}`);

  // 确保有 peer 连接
  let peer = peers.get(from);
  let pc;
  if (!peer || !peer.pc) {
    pc = createPeerConnection(from, false);
    peer = peers.get(from);
  } else {
    pc = peer.pc;
  }

  pc.setRemoteDescription(new RTCSessionDescription(offer))
    .then(() => pc.createAnswer())
    .then(answer => pc.setLocalDescription(answer))
    .then(() => {
      sendWs({
        type: 'answer',
        to: from,
        answer: pc.localDescription
      });
    })
    .catch(err => console.error('处理 offer 失败:', err));
}

function handleAnswer(from, answer) {
  console.log(`收到 answer 来自 ${from}`);

  const peer = peers.get(from);
  if (peer && peer.pc) {
    peer.pc.setRemoteDescription(new RTCSessionDescription(answer))
      .catch(err => console.error('设置 answer 失败:', err));
  }
}

function handleIceCandidate(from, candidate) {
  const peer = peers.get(from);
  if (peer && peer.pc && candidate) {
    peer.pc.addIceCandidate(new RTCIceCandidate(candidate))
      .catch(err => console.error('添加 ICE 候选失败:', err));
  }
}

// ===== 播放远端音频 =====
function playRemoteAudio(userId, stream) {
  let audioEl = document.getElementById('audio-' + userId);
  if (!audioEl) {
    audioEl = document.createElement('audio');
    audioEl.id = 'audio-' + userId;
    audioEl.autoplay = true;
    audioEl.style.display = 'none';
    document.body.appendChild(audioEl);
  }
  audioEl.srcObject = stream;
  audioEl.muted = !isAudioOn;
}

// ===== 麦克风控制 =====
async function toggleMic() {
  if (isMicOn) {
    stopLocalAudio();
  } else {
    await startLocalAudio();
  }
}

async function startLocalAudio() {
  try {
    localAudioStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      }
    });

    isMicOn = true;
    micBtn.classList.add('active');
    micBtn.querySelector('.control-text').textContent = '闭麦';

    // 将音频流添加到所有已有 peer 连接
    peers.forEach((peer, uid) => {
      if (peer.pc && localAudioStream) {
        localAudioStream.getAudioTracks().forEach(track => {
          // 检查是否已经添加过
          const senders = peer.pc.getSenders();
          const exists = senders.some(s => s.track && s.track.kind === 'audio');
          if (!exists) {
            peer.pc.addTrack(track, localAudioStream);
          }
        });
      }
    });

    console.log('麦克风已开启');
  } catch (err) {
    console.error('获取麦克风失败:', err);
    alert('无法访问麦克风，请检查浏览器权限设置。\n错误: ' + err.message);
  }
}

function stopLocalAudio() {
  if (localAudioStream) {
    localAudioStream.getTracks().forEach(track => track.stop());
    localAudioStream = null;
  }

  isMicOn = false;
  micBtn.classList.remove('active');
  micBtn.querySelector('.control-text').textContent = '开麦';

  // 从所有 peer 连接中移除音频轨
  peers.forEach((peer) => {
    if (peer.pc) {
      peer.pc.getSenders().forEach(sender => {
        if (sender.track && sender.track.kind === 'audio') {
          peer.pc.removeTrack(sender);
        }
      });
    }
  });

  console.log('麦克风已关闭');
}

// ===== 声音控制（扬声器） =====
function toggleAudio() {
  isAudioOn = !isAudioOn;

  if (isAudioOn) {
    audioBtn.classList.add('active');
    audioBtn.querySelector('.control-text').textContent = '静音';
  } else {
    audioBtn.classList.remove('active');
    audioBtn.querySelector('.control-text').textContent = '开启声音';
  }

  // 更新所有远端音频
  peers.forEach((peer, uid) => {
    const audioEl = document.getElementById('audio-' + uid);
    if (audioEl) {
      audioEl.muted = !isAudioOn;
    }
  });
}

// ===== 屏幕共享 =====
async function toggleScreenShare() {
  if (isSharing) {
    stopScreenShare();
  } else {
    await startScreenShare();
  }
}

async function startScreenShare() {
  try {
    localScreenStream = await navigator.mediaDevices.getDisplayMedia({
      video: true,
      audio: false
    });

    isSharing = true;
    shareBtn.classList.add('active');
    shareBtn.querySelector('.control-text').textContent = '停止共享';

    // 本地也显示
    screenVideo.srcObject = localScreenStream;
    screenVideo.classList.add('active');
    screenPlaceholder.style.display = 'none';
    screenStatusText.textContent = '你正在共享屏幕';
    fullscreenBtn.disabled = false;

    // 更新自己的状态
    const myInfo = members.get(myUserId);
    if (myInfo) {
      myInfo.isSharing = true;
      updateMemberList();
    }

    // 通知服务器
    sendWs({ type: 'screen-start' });

    // 为每个已连接的 peer 创建屏幕共享连接
    peers.forEach((peer, uid) => {
      createScreenPeerConnection(uid, true);
    });

    // 监听停止事件（用户点浏览器的停止共享按钮）
    localScreenStream.getVideoTracks()[0].addEventListener('ended', () => {
      stopScreenShare();
    });

    console.log('屏幕共享已开启');
  } catch (err) {
    console.error('屏幕共享失败:', err);
    if (err.name !== 'NotAllowedError') {
      alert('屏幕共享失败: ' + err.message);
    }
  }
}

function stopScreenShare() {
  if (localScreenStream) {
    localScreenStream.getTracks().forEach(track => track.stop());
    localScreenStream = null;
  }

  isSharing = false;
  shareBtn.classList.remove('active');
  shareBtn.querySelector('.control-text').textContent = '共享屏幕';

  // 通知服务器
  if (isInRoom) {
    sendWs({ type: 'screen-end' });

    // 关闭所有屏幕共享 peer 连接
    peers.forEach((peer) => {
      if (peer.screenPc) {
        peer.screenPc.close();
        peer.screenPc = null;
      }
      peer.screenStream = null;
    });
  }

  // 如果本地在显示自己的共享，停止显示
  if (screenVideo.srcObject === localScreenStream || !currentScreenSharerId) {
    screenVideo.srcObject = null;
    screenVideo.classList.remove('active');
    screenPlaceholder.style.display = 'flex';
    screenStatusText.textContent = '等待屏幕共享';
    fullscreenBtn.disabled = true;
  }

  // 更新自己的状态
  if (isInRoom) {
    const myInfo = members.get(myUserId);
    if (myInfo) {
      myInfo.isSharing = false;
      updateMemberList();
    }
  }

  console.log('屏幕共享已停止');
}

function handleScreenStarted(userId, userName) {
  const member = members.get(userId);
  if (member) {
    member.isSharing = true;
    updateMemberList();
  }

  // 如果还没有显示任何屏幕共享，显示这个
  if (!currentScreenSharerId && userId !== myUserId) {
    currentScreenSharerId = userId;
    screenStatusText.textContent = `${userName} 正在共享屏幕`;
    // 等对方发 screen-offer
  }
}

function handleScreenStopped(userId) {
  const member = members.get(userId);
  if (member) {
    member.isSharing = false;
    updateMemberList();
  }

  // 关闭对应的屏幕 peer
  const peer = peers.get(userId);
  if (peer && peer.screenPc) {
    peer.screenPc.close();
    peer.screenPc = null;
    peer.screenStream = null;
  }

  // 如果停止的是当前显示的共享
  if (currentScreenSharerId === userId) {
    currentScreenSharerId = null;
    screenVideo.srcObject = null;
    screenVideo.classList.remove('active');
    screenPlaceholder.style.display = 'flex';
    screenStatusText.textContent = '等待屏幕共享';
    fullscreenBtn.disabled = true;

    // 看看有没有其他人在共享
    members.forEach((info, uid) => {
      if (info.isSharing && uid !== myUserId && !currentScreenSharerId) {
        currentScreenSharerId = uid;
        screenStatusText.textContent = `${info.name} 正在共享屏幕`;
      }
    });
  }
}

// ===== WebRTC 屏幕共享连接 =====
function createScreenPeerConnection(remoteUserId, isInitiator) {
  const peer = peers.get(remoteUserId);
  if (!peer) return null;

  // 如果已有 screenPc，先关了
  if (peer.screenPc) {
    peer.screenPc.close();
    peer.screenPc = null;
  }

  console.log(`创建屏幕共享 PeerConnection，对方: ${remoteUserId}, 发起方: ${isInitiator}`);

  const pc = new RTCPeerConnection(iceConfig);
  peer.screenPc = pc;

  // 如果我们在共享屏幕，添加视频轨
  if (localScreenStream && isInitiator) {
    localScreenStream.getVideoTracks().forEach(track => {
      pc.addTrack(track, localScreenStream);
    });
  }

  // 接收远端屏幕视频
  pc.ontrack = (event) => {
    if (event.track.kind === 'video') {
      peer.screenStream = event.streams[0];

      // 如果这是当前显示的共享者，更新画面
      if (remoteUserId === currentScreenSharerId) {
        screenVideo.srcObject = event.streams[0];
        screenVideo.classList.add('active');
        screenPlaceholder.style.display = 'none';
        fullscreenBtn.disabled = false;
      }
    }
  };

  pc.onicecandidate = (event) => {
    if (event.candidate) {
      sendWs({
        type: 'screen-ice-candidate',
        to: remoteUserId,
        candidate: event.candidate
      });
    }
  };

  pc.onconnectionstatechange = () => {
    console.log(`屏幕共享连接状态 (${remoteUserId}): ${pc.connectionState}`);
  };

  if (isInitiator && localScreenStream) {
    setTimeout(() => {
      pc.createOffer()
        .then(offer => pc.setLocalDescription(offer))
        .then(() => {
          sendWs({
            type: 'screen-offer',
            to: remoteUserId,
            offer: pc.localDescription
          });
        })
        .catch(err => console.error('创建 screen offer 失败:', err));
    }, 300);
  }

  return pc;
}

function handleScreenOffer(from, offer) {
  console.log(`收到 screen offer 来自 ${from}`);

  let peer = peers.get(from);
  if (!peer) {
    // 先创建语音连接
    createPeerConnection(from, false);
    peer = peers.get(from);
  }

  let screenPc = peer.screenPc;
  if (!screenPc) {
    screenPc = createScreenPeerConnection(from, false);
    peer = peers.get(from);
    screenPc = peer.screenPc;
  }

  if (screenPc) {
    screenPc.setRemoteDescription(new RTCSessionDescription(offer))
      .then(() => screenPc.createAnswer())
      .then(answer => screenPc.setLocalDescription(answer))
      .then(() => {
        sendWs({
          type: 'screen-answer',
          to: from,
          answer: screenPc.localDescription
        });
      })
      .catch(err => console.error('处理 screen offer 失败:', err));
  }
}

function handleScreenAnswer(from, answer) {
  const peer = peers.get(from);
  if (peer && peer.screenPc) {
    peer.screenPc.setRemoteDescription(new RTCSessionDescription(answer))
      .catch(err => console.error('设置 screen answer 失败:', err));
  }
}

function handleScreenIceCandidate(from, candidate) {
  const peer = peers.get(from);
  if (peer && peer.screenPc && candidate) {
    peer.screenPc.addIceCandidate(new RTCIceCandidate(candidate))
      .catch(err => console.error('添加 screen ICE 候选失败:', err));
  }
}

// ===== 文字聊天 =====
function sendChatMessage() {
  const text = chatInput.value.trim();
  if (!text || !isInRoom) return;

  sendWs({
    type: 'chat',
    text
  });

  chatInput.value = '';
}

function handleChatMessage(data) {
  addChatMessage(data.userId, data.userName, data.text, data.time);
}

function handleChatHistory(messages) {
  chatMessages.innerHTML = '';
  messages.forEach(msg => {
    addChatMessage(msg.userId, msg.userName, msg.text, msg.time);
  });
}

function addChatMessage(userId, userName, text, time) {
  const emptyEl = chatMessages.querySelector('.empty-chat');
  if (emptyEl) emptyEl.remove();

  const isSelf = userId === myUserId;
  const msgEl = document.createElement('div');
  msgEl.className = 'chat-message' + (isSelf ? ' self' : '');

  const timeStr = new Date(time).toLocaleTimeString('zh-CN', {
    hour: '2-digit',
    minute: '2-digit'
  });

  msgEl.innerHTML = `
    <div class="msg-header">
      <span class="msg-name">${userName}</span>
      <span class="msg-time">${timeStr}</span>
    </div>
    <div class="msg-text">${escapeHtml(text)}</div>
  `;

  chatMessages.appendChild(msgEl);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ===== 静音状态同步 =====
function handleMuteUpdate(userId, muted) {
  const member = members.get(userId);
  if (member) {
    member.muted = muted;
    updateMemberList();
  }
}

// ===== 全屏 =====
function toggleFullscreen() {
  const container = $('screenContainer');
  if (document.fullscreenElement) {
    document.exitFullscreen();
  } else {
    container.requestFullscreen().catch(err => {
      console.error('全屏失败:', err);
    });
  }
}

// ===== 快速生成会议号 =====
function generateRoomId() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// ===== 事件绑定 =====
function bindEvents() {
  createBtn.addEventListener('click', () => {
    if (!roomIdInput.value.trim()) {
      roomIdInput.value = generateRoomId();
    }
    joinRoom();
  });

  joinBtn.addEventListener('click', joinRoom);
  leaveBtn.addEventListener('click', leaveRoom);

  micBtn.addEventListener('click', toggleMic);
  audioBtn.addEventListener('click', toggleAudio);
  shareBtn.addEventListener('click', toggleScreenShare);
  fullscreenBtn.addEventListener('click', toggleFullscreen);

  sendBtn.addEventListener('click', sendChatMessage);
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendChatMessage();
    }
  });

  // 页面关闭时离开
  window.addEventListener('beforeunload', () => {
    if (isInRoom) {
      sendWs({ type: 'leave' });
    }
  });
}

// ===== 启动 =====
init();
